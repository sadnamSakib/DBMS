#include <bits/stdc++.h>
#define endl "\n"

using namespace std;

map<string, set<char>> functional_dependencies;
set<char> attributes;
set<char> PA;
set<char> DA;
set<string> candidate_keys;
string relation;
string functionalDependenciesAsString;
vector<string> functionalDependencyStrings;
map<string, bool> listOfCandidateKeys;

void read_file();
void write_file(set<string> &input_set);
void extract_attributes();
void extract_dependencies();
void dfs(string current, map<string, bool> &visited, set<char> &given);
void generateSubsequences(string given, set<string> &s);
void generatePSS(string after, set<string> &s, string given);
set<char> find_closure(string given);
bool is_super_key(string given);
bool is_candidate_key(string given);
string findFirstCandidateKey();
void build_dependency_graph();
bool more_candidate_keys_exist(vector<char> &intersection);
vector<char> replacemenet_policy(char c);
void replacement_process(string firstkey, vector<char> &replacable_attributes);

int main()
{
   
    read_file();
    //extracting attributes from relation string
    extract_attributes();
    //extracting dependencies from string
    extract_dependencies();
    //building dependency graph
    build_dependency_graph();

    // finding the first key
    vector<char> replacable_attributes;
    replacement_process(findFirstCandidateKey(), replacable_attributes);

    // writes in output file
    write_file(candidate_keys);
    return 0;
}

// reads from input file using the fstream library in c++
void read_file()
{
    string line;
    fstream file;
    file.open("input.txt", ios::in);

    getline(file, relation);
    getline(file, functionalDependenciesAsString);
}

// writes in output file using fstream library

void write_file(set<string> &input_set)
{

    ofstream f("output.txt");

    for (auto &element : input_set)
    {
        f << element << endl;
    }

    f.close();
}

// extracts the attributes from given relation , first we delete the first R that is in the string to avoid taking it into our attributes
// then we take only the capital letters as attributes of our relation
void extract_attributes()
{
    relation.erase(relation.begin(), relation.begin() + 1);
    for (auto u : relation)
    {
        if (u >= 'A' && u <= 'Z')
        {
            attributes.insert(u);
        }
    }
}

// extracts the dependencies as strings from given functional dependencies , if there is a space before
// we delete that space character to make it easier to extract
void extract_dependencies()
{
    stringstream functionalDependenciesAsString_ss(functionalDependenciesAsString);
    string functionalDependency;
    while (getline(functionalDependenciesAsString_ss, functionalDependency, ','))
    {
        if (functionalDependency[0] == ' ')
            functionalDependency.erase(functionalDependency.begin());
        functionalDependencyStrings.push_back(functionalDependency);
    }
}

// depth first traversal through the list of dependencies to find trivial dependencies , like a basic depth first search in graphs
// we input the current node in our given set , traverse through its dependencies and recursively repeat the process
void dfs(string current, map<string, bool> &visited, set<char> &given)
{
    visited[current] = true;
    for (auto u : current)
    {
        given.insert(u);
    }
    for (auto u : functional_dependencies[current])
    {
        string k = "";
        k += u;
        sort(k.begin(), k.end());
        if (visited.find(k) == visited.end())
        {
            dfs(k, visited, given);
        }
    }
}

// generates all possible subsequence of given string and stores them in a set , we use a recursive function here 
// which deletes each letter of the given string and adds them in the given set
void generateSubsequences(string given, set<string> &s)
{

    sort(given.begin(), given.end());
    s.insert(given);
    string temp = "";

    for (int i = 0; i < given.length(); i++)
    {
        string d = given;
        d.erase(i, 1);
        generateSubsequences(d, s);
    }
}

// generates only the proper subsequences of a given string , this is later used to check if a key is a candidate key
// no proper subset of a candidate key can be a superkey
void generatePSS(string after, set<string> &s, string given)
{

    sort(after.begin(), after.end());
    sort(given.begin(), given.end());
    if (given != after)
        s.insert(after);
    string temp = "";

    for (int i = 0; i < after.length(); i++)
    {
        string d = after;
        d.erase(i, 1);
        generateSubsequences(d, s);
    }
}

// finds closure by generating all possible subsequence of a given string and traversing through the dependencies using
// dfs algorithm written before , we have also included the characters of the given string as a key can determine itself
set<char> find_closure(string given)
{
    set<char> result;
    for (auto u : given)
    {
        result.insert(u);
    }
    set<string> subsequences;
    generateSubsequences(given, subsequences);
    for (auto k : subsequences)
    {
        map<string, bool> visited;
        dfs(k, visited, result);
    }

    return result;
}

// determines if a given string is a super_key by finding its closure and checking if the size of the closure matches
// the attribute set's size. If it does that means it is a super key
bool is_super_key(string given)
{
    return find_closure(given).size() == attributes.size();
}

// determines if a given string is a candidate key by checking if no propersubset is a superkey , here we need
// the generatePSS function which was written earlier. We go through each PSS to check if they are a super key or not
bool is_candidate_key(string given)
{
    set<string> PSS;
    generatePSS(given, PSS, given);
    for (auto u : PSS)
    {
        if (is_super_key(u))
        {
            return false;
        }
    }
    return true;
}

// finds the first candidate key and return it as a string. We generate all subsequence of the key and check if one
// is a candidate key or not . We sort the keys so that we can get the lexicographically smallest key first which
// makes our calculation easier. This is the end of step 1 of method 3.
string findFirstCandidateKey()
{
    string given = "";
    for (auto u : attributes)
    {
        given += u;
    }
    set<string> subsequences;
    generateSubsequences(given, subsequences);
    vector<string> ck;
    for (auto u : subsequences)
    {
        if (is_super_key(u))
        {
            ck.push_back(u);
            if (is_candidate_key(u))
            {
                candidate_keys.insert(u);
            }
        }
    }
    sort(ck.begin(), ck.end());
    for (auto u : ck)
    {
        if (listOfCandidateKeys.find(u) == listOfCandidateKeys.end())
        {
            listOfCandidateKeys[u] = true;
            for (auto k : u)
            {
                PA.insert(k);
            }
            return u;
        }
    }
    return given;
}

// builds the dependency graph which helps us traverse and find trivial dependencies.We keep it in a key value pair map
// our key here is a string and value is a set of characters
void build_dependency_graph()
{
    for (auto u : functionalDependencyStrings)
    {

        auto pos = u.find("->");
        string before = u.substr(0, pos);
        string after = u.substr(pos + 2);
        for (auto u : before)
        {
            functional_dependencies[before].insert(u);
        }
        for (auto u : after)
        {
            functional_dependencies[before].insert(u);
            DA.insert(u);
        }
    }
}

// checks if after each step there are more candidate keys available by intersecting PA and DA
bool more_candidate_keys_exist(vector<char> &intersection)
{

    set_intersection(PA.begin(), PA.end(), DA.begin(), DA.end(), back_inserter(intersection));
    return true;
}

// replaces given characters with their corresponding replacement attributes
vector<char> replacemenet_policy(char c)
{
    vector<char> replacementAttribute;
    for (auto u : attributes)
    {
        if (u == c)
        {
            continue;
        }
        string it = "";
        it += u;
        set<char> closure = find_closure(it);
        if (closure.find(c) != closure.end())
        {
            replacementAttribute.push_back(u);
        }
    }
    return replacementAttribute;
}

//this function handles step 2 which replaces each replacable attribute of our first found candidate key.Later on , we use
// a brute force approach to replace each and check if they make a candidate key or not. If they do , we store them in a vector of canidate keys
void replacement_process(string firstkey, vector<char> &replacable_attributes)
{
    if (!more_candidate_keys_exist(replacable_attributes))
    {

        write_file(candidate_keys);
        return;
    }
    else
    {
        // replaces each attribute with its replacement and checks if that is a canidate key
        for (int i = 0; i < replacable_attributes.size(); i++)
        {
            char c = replacable_attributes[i];
            vector<char> replacements = replacemenet_policy(c);
            for (auto u : replacements)
            {
                string d = firstkey;
                d[i] = u;
                if (is_candidate_key(d))
                {
                    candidate_keys.insert(d);
                }
            }
        }
    }
}